package com.example.studyassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studyassistant.data.local.SubjectEntity
import com.example.studyassistant.ui.ConfirmDialog
import com.example.studyassistant.ui.NoInsets
import com.example.studyassistant.ui.containerViewModel
import com.example.studyassistant.ui.viewmodels.SubjectsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectsScreen(onOpen: (Int) -> Unit) {
    val vm = containerViewModel { SubjectsViewModel(it.repo) }
    val subjects by vm.subjects.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<SubjectEntity?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Предметы") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showAdd = true }) { Text("+ Создать предмет") }
        },
        contentWindowInsets = NoInsets
    ) { pad ->
        if (subjects.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Предметов пока нет")
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(subjects, key = { it.id }) { s ->
                    Card(onClick = { onOpen(s.id) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(s.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            IconButton(onClick = { toDelete = s }) { Icon(Icons.Default.Delete, "Удалить") }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var title by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Новый предмет") },
            text = { OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(enabled = title.isNotBlank(), onClick = { vm.add(title.trim()); showAdd = false }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } }
        )
    }
    toDelete?.let { s ->
        ConfirmDialog(
            "Удалить «${s.title}» вместе с расписанием, задачами, инструментами и работами?",
            onConfirm = { vm.delete(s.id) },
            onDismiss = { toDelete = null }
        )
    }
}
