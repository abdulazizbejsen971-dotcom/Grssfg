package com.example.studyassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studyassistant.ui.NoInsets
import com.example.studyassistant.ui.containerViewModel
import com.example.studyassistant.ui.viewmodels.ChatViewModel
import com.mikepenz.markdown.m3.Markdown
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(agentId: Int, onBack: () -> Unit) {
    val vm = containerViewModel { ChatViewModel(it.repo, it.gemini, agentId) }
    val agent by vm.agent.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var toSave by remember { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()

    val extra = if (ui.loading || ui.error != null) 1 else 0
    LaunchedEffect(messages.size, extra) {
        val count = messages.size + extra
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(agent?.title ?: "") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = { TextButton(onClick = { vm.clearChat() }) { Text("Очистить") } }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Сообщение…") },
                    maxLines = 5
                )
                IconButton(
                    enabled = input.isNotBlank() && !ui.loading,
                    onClick = { vm.send(input); input = "" }
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Отправить") }
            }
        },
        contentWindowInsets = NoInsets
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { m ->
                if (m.sender == "USER") {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) { Text(m.text, Modifier.padding(12.dp)) }
                    }
                } else {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Markdown(m.text)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { toSave = m.text }) { Text("💾 Сохранить в предмет") }
                                TextButton(onClick = { clipboard.setText(AnnotatedString(m.text)) }) { Text("Копировать") }
                            }
                        }
                    }
                }
            }
            if (ui.loading) {
                item(key = "loading") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("Генерация…")
                    }
                }
            }
            ui.error?.let { err ->
                item(key = "error") {
                    Column {
                        Text(err, color = MaterialTheme.colorScheme.error)
                        TextButton(onClick = { vm.retry() }) { Text("Повторить") }
                    }
                }
            }
        }
    }

    toSave?.let { text ->
        SaveWorkDialog(
            defaultTitle = agent?.title.orEmpty(),
            defaultCategory = agent?.title.orEmpty(),
            onDismiss = { toSave = null },
            onSave = { title, category ->
                vm.saveWork(title, category, text)
                toSave = null
                scope.launch { snackbar.showSnackbar("Сохранено в предмет") }
            }
        )
    }
}

@Composable
private fun SaveWorkDialog(
    defaultTitle: String,
    defaultCategory: String,
    onDismiss: () -> Unit,
    onSave: (title: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf(defaultTitle) }
    var category by remember { mutableStateOf(defaultCategory) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Сохранить в предмет") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Название (Лабораторная №1)") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Категория (Лабораторные)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && category.isNotBlank(), onClick = { onSave(title.trim(), category.trim()) }) {
                Text("Сохранить")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
