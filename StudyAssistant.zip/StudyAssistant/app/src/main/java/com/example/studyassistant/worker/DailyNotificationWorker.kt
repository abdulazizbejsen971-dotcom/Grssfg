package com.example.studyassistant.worker

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.studyassistant.StudyApp
import com.example.studyassistant.util.dayBounds
import com.example.studyassistant.util.toAppDay
import java.util.Calendar
import java.util.concurrent.TimeUnit

class DailyNotificationWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val repo = (applicationContext as StudyApp).container.repo
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        val (from, to) = dayBounds(tomorrow)

        val lessons = repo.getSchedule(toAppDay(tomorrow))
        val tasks = repo.getPendingTasksBetween(from, to)
        if (lessons.isEmpty() && tasks.isEmpty()) return Result.success()

        val text = buildString {
            if (lessons.isNotEmpty()) {
                appendLine("Уроки:")
                lessons.forEach {
                    appendLine("• ${it.schedule.startTime} ${it.subjectTitle} (${it.schedule.room})")
                }
            }
            if (tasks.isNotEmpty()) {
                if (lessons.isNotEmpty()) appendLine()
                appendLine("Задачи на завтра:")
                tasks.forEach { appendLine("• ${it.task.title} — ${it.subjectTitle}") }
            }
        }.trim()

        val nm = NotificationManagerCompat.from(applicationContext)
        if (!nm.areNotificationsEnabled()) return Result.success()

        val channel = NotificationChannel(CHANNEL_ID, "Напоминания", NotificationManager.IMPORTANCE_DEFAULT)
        applicationContext.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Завтра: ${lessons.size} ур., ${tasks.size} задач")
            .setContentText(text.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFICATION_ID, notification)
        return Result.success()
    }

    private companion object {
        const val CHANNEL_ID = "daily_reminder"
        const val NOTIFICATION_ID = 1001
    }
}

object NotificationScheduler {
    private const val WORK_NAME = "daily_notification"

    /** Ежедневный запуск около 20:00. WorkManager может сдвинуть время на несколько минут. */
    fun schedule(context: Context) {
        val now = Calendar.getInstance()
        val next = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 20); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val request = PeriodicWorkRequestBuilder<DailyNotificationWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(next.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }
}
