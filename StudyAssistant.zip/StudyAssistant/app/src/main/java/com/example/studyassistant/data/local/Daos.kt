package com.example.studyassistant.data.local

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class ScheduleItem(@Embedded val schedule: ScheduleEntity, val subjectTitle: String)
data class TaskItem(@Embedded val task: TaskEntity, val subjectTitle: String)

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY title")
    fun observeAll(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects WHERE id = :id")
    fun observe(id: Int): Flow<SubjectEntity?>

    @Insert suspend fun insert(subject: SubjectEntity): Long

    @Query("DELETE FROM subjects WHERE id = :id")
    suspend fun delete(id: Int)
}

@Dao
interface ScheduleDao {
    @Query(
        "SELECT sc.*, s.title AS subjectTitle FROM schedule sc " +
            "JOIN subjects s ON s.id = sc.subjectId WHERE sc.dayOfWeek = :day ORDER BY sc.startTime"
    )
    fun observeByDay(day: Int): Flow<List<ScheduleItem>>

    @Query(
        "SELECT sc.*, s.title AS subjectTitle FROM schedule sc " +
            "JOIN subjects s ON s.id = sc.subjectId WHERE sc.dayOfWeek = :day ORDER BY sc.startTime"
    )
    suspend fun getByDay(day: Int): List<ScheduleItem>

    @Insert suspend fun insert(item: ScheduleEntity): Long

    @Query("DELETE FROM schedule WHERE id = :id")
    suspend fun delete(id: Int)
}

@Dao
interface TaskDao {
    @Query(
        "SELECT t.*, s.title AS subjectTitle FROM tasks t " +
            "JOIN subjects s ON s.id = t.subjectId ORDER BY t.isCompleted, t.dueDateTimestamp"
    )
    fun observeAll(): Flow<List<TaskItem>>

    @Query(
        "SELECT t.*, s.title AS subjectTitle FROM tasks t JOIN subjects s ON s.id = t.subjectId " +
            "WHERE t.isCompleted = 0 AND t.dueDateTimestamp BETWEEN :from AND :to ORDER BY t.dueDateTimestamp"
    )
    suspend fun getPendingBetween(from: Long, to: Long): List<TaskItem>

    @Insert suspend fun insert(task: TaskEntity): Long

    @Query("UPDATE tasks SET isCompleted = :done WHERE id = :id")
    suspend fun setCompleted(id: Int, done: Boolean)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun delete(id: Int)
}

@Dao
interface AgentDao {
    @Query("SELECT * FROM subject_agents WHERE subjectId = :subjectId ORDER BY title")
    fun observeBySubject(subjectId: Int): Flow<List<SubjectAgentEntity>>

    @Query("SELECT * FROM subject_agents WHERE id = :id")
    fun observe(id: Int): Flow<SubjectAgentEntity?>

    @Query("SELECT * FROM subject_agents WHERE id = :id")
    suspend fun get(id: Int): SubjectAgentEntity?

    @Insert suspend fun insert(agent: SubjectAgentEntity): Long

    @Query("DELETE FROM subject_agents WHERE id = :id")
    suspend fun delete(id: Int)
}

@Dao
interface SavedWorkDao {
    @Query("SELECT * FROM saved_works WHERE subjectId = :subjectId ORDER BY categoryName, createdAtTimestamp DESC")
    fun observeBySubject(subjectId: Int): Flow<List<SavedWorkEntity>>

    @Query("SELECT * FROM saved_works WHERE id = :id")
    fun observe(id: Int): Flow<SavedWorkEntity?>

    @Insert suspend fun insert(work: SavedWorkEntity): Long

    @Query("UPDATE saved_works SET title = :title, contentMarkdown = :content WHERE id = :id")
    suspend fun update(id: Int, title: String, content: String)

    @Query("DELETE FROM saved_works WHERE id = :id")
    suspend fun delete(id: Int)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE agentId = :agentId ORDER BY timestamp, id")
    fun observeByAgent(agentId: Int): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE agentId = :agentId ORDER BY timestamp, id")
    suspend fun getByAgent(agentId: Int): List<ChatMessageEntity>

    @Insert suspend fun insert(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages WHERE agentId = :agentId")
    suspend fun clear(agentId: Int)
}
