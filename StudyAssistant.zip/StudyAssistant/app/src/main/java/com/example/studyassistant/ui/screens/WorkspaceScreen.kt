package com.example.studyassistant.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studyassistant.data.local.SavedWorkEntity
import com.example.studyassistant.data.local.SubjectAgentEntity
import com.example.studyassistant.ui.ConfirmDialog
import com.example.studyassistant.ui.containerViewModel
import com.example.studyassistant.ui.viewmodels.WorkspaceViewModel
import com.example.studyassistant.util.formatDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceScreen(
    subjectId: Int,
    onBack: () -> Unit,
    onOpenAgent: (Int) -> Unit,
    onOpenWork: (Int) -> Unit
) {
    val vm = containerViewModel { WorkspaceViewModel(it.repo, subjectId) }
    val subject by vm.subject.collectAsStateWithLifecycle()
    val agents by vm.agents.collectAsStateWithLifecycle()
    val works by vm.works.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(subject?.title ?: "") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Инструменты") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Готовые работы") })
            }
            if (tab == 0) {
                AgentsTab(agents, onAdd = vm::addAgent, onOpen = onOpenAgent, onDelete = vm::deleteAgent)
            } else {
                WorksTab(works, onOpen = onOpenWork, onDelete = vm::deleteWork)
            }
        }
    }
}

@Composable
private fun AgentsTab(
    agents: List<SubjectAgentEntity>,
    onAdd: (String, String) -> Unit,
    onOpen: (Int) -> Unit,
    onDelete: (Int) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<SubjectAgentEntity?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Добавить инструмент") } }
        items(agents, key = { it.id }) { a ->
            Card(onClick = { onOpen(a.id) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                        Text(a.title, style = MaterialTheme.typography.titleMedium)
                        Text(a.systemPrompt, maxLines = 2, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { toDelete = a }) { Icon(Icons.Default.Delete, "Удалить") }
                }
            }
        }
    }

    if (showAdd) {
        var title by remember { mutableStateOf("") }
        var prompt by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Новый инструмент") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Название (например, Реферат)") }, singleLine = true)
                    OutlinedTextField(prompt, { prompt = it }, label = { Text("System Prompt") }, minLines = 4, maxLines = 8)
                }
            },
            confirmButton = {
                TextButton(enabled = title.isNotBlank() && prompt.isNotBlank(), onClick = {
                    onAdd(title.trim(), prompt.trim()); showAdd = false
                }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } }
        )
    }
    toDelete?.let { a ->
        ConfirmDialog("Удалить инструмент «${a.title}» и историю чата?", { onDelete(a.id) }, { toDelete = null })
    }
}

@Composable
private fun WorksTab(works: List<SavedWorkEntity>, onOpen: (Int) -> Unit, onDelete: (Int) -> Unit) {
    var collapsed by remember { mutableStateOf(setOf<String>()) }
    var toDelete by remember { mutableStateOf<SavedWorkEntity?>(null) }
    val grouped = works.groupBy { it.categoryName }

    if (works.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Сохранённых работ пока нет")
        }
        return
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        grouped.forEach { (category, list) ->
            item(key = "c_$category") {
                Text(
                    (if (category in collapsed) "📁 " else "📂 ") + "$category (${list.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.fillMaxWidth()
                        .clickable { collapsed = if (category in collapsed) collapsed - category else collapsed + category }
                        .padding(16.dp)
                )
            }
            if (category !in collapsed) {
                items(list, key = { "w_${it.id}" }) { w ->
                    ListItem(
                        headlineContent = { Text(w.title) },
                        supportingContent = { Text(formatDate(w.createdAtTimestamp)) },
                        trailingContent = {
                            IconButton(onClick = { toDelete = w }) { Icon(Icons.Default.Delete, "Удалить") }
                        },
                        modifier = Modifier.clickable { onOpen(w.id) }
                    )
                }
            }
        }
    }

    toDelete?.let { w ->
        ConfirmDialog("Удалить «${w.title}»?", { onDelete(w.id) }, { toDelete = null })
    }
}
