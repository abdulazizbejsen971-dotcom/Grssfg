package com.example.studyassistant.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

val DAY_NAMES = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб")
val TIME_REGEX = Regex("([01]\\d|2[0-3]):[0-5]\\d")

/** 1 = Пн ... 6 = Сб, 7 = Вс. */
fun toAppDay(c: Calendar): Int {
    val d = c.get(Calendar.DAY_OF_WEEK)
    return if (d == Calendar.SUNDAY) 7 else d - 1
}

/** Для главного экрана: в воскресенье показываем понедельник. */
fun defaultDay(): Int = toAppDay(Calendar.getInstance()).let { if (it > 6) 1 else it }

/** Начало и конец суток (локальное время) для указанной даты. */
fun dayBounds(c: Calendar): Pair<Long, Long> {
    val start = (c.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val end = (start.clone() as Calendar).apply {
        add(Calendar.DAY_OF_YEAR, 1); add(Calendar.MILLISECOND, -1)
    }
    return start.timeInMillis to end.timeInMillis
}

fun endOfTodayMillis(): Long = dayBounds(Calendar.getInstance()).second

/** DatePicker отдаёт UTC-полночь выбранной даты; переводим в конец этого дня по локальному времени. */
fun utcDateToLocalEndOfDay(utcMillis: Long): Long {
    val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMillis }
    return Calendar.getInstance().apply {
        clear()
        set(utc.get(Calendar.YEAR), utc.get(Calendar.MONTH), utc.get(Calendar.DAY_OF_MONTH), 23, 59, 59)
    }.timeInMillis
}

/** Обратное преобразование — для начального значения DatePicker. */
fun localToUtcDateMillis(ts: Long): Long {
    val local = Calendar.getInstance().apply { timeInMillis = ts }
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

fun formatDate(ts: Long): String =
    SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(ts))
