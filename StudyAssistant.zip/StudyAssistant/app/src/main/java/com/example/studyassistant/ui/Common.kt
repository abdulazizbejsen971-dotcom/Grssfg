package com.example.studyassistant.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.studyassistant.AppContainer
import com.example.studyassistant.StudyApp
import com.example.studyassistant.data.local.SubjectEntity

val NoInsets = WindowInsets(0, 0, 0, 0)

@Composable
inline fun <reified VM : ViewModel> containerViewModel(crossinline create: (AppContainer) -> VM): VM {
    val container = (LocalContext.current.applicationContext as StudyApp).container
    return viewModel<VM>(factory = viewModelFactory { initializer { create(container) } })
}

@Composable
fun SectionHeader(title: String, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        IconButton(onClick = onAdd) { Icon(Icons.Default.Add, contentDescription = "Добавить") }
    }
}

@Composable
fun SubjectPicker(subjects: List<SubjectEntity>, selectedId: Int?, onSelect: (Int) -> Unit) {
    Column(Modifier.heightIn(max = 180.dp).verticalScroll(rememberScrollState())) {
        subjects.forEach { s ->
            Row(
                Modifier.fillMaxWidth().clickable { onSelect(s.id) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = s.id == selectedId, onClick = { onSelect(s.id) })
                Text(s.title)
            }
        }
    }
}

@Composable
fun ConfirmDialog(text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text("Удалить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
