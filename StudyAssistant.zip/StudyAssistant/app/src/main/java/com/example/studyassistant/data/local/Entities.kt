package com.example.studyassistant.data.local

import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Entity

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String
)

@Entity(
    tableName = "schedule",
    foreignKeys = [ForeignKey(
        entity = SubjectEntity::class, parentColumns = ["id"],
        childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId")]
)
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectId: Int,
    val dayOfWeek: Int,          // 1 = Пн ... 6 = Сб
    val startTime: String,       // "08:30"
    val endTime: String,         // "10:00"
    val room: String
)

@Entity(
    tableName = "tasks",
    foreignKeys = [ForeignKey(
        entity = SubjectEntity::class, parentColumns = ["id"],
        childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId")]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectId: Int,
    val title: String,
    val dueDateTimestamp: Long,
    val isCompleted: Boolean = false
)

@Entity(
    tableName = "subject_agents",
    foreignKeys = [ForeignKey(
        entity = SubjectEntity::class, parentColumns = ["id"],
        childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId")]
)
data class SubjectAgentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectId: Int,
    val title: String,
    val systemPrompt: String
)

@Entity(
    tableName = "saved_works",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class, parentColumns = ["id"],
            childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SubjectAgentEntity::class, parentColumns = ["id"],
            childColumns = ["agentId"], onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("subjectId"), Index("agentId")]
)
data class SavedWorkEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectId: Int,
    val agentId: Int? = null,
    val categoryName: String,
    val title: String,
    val contentMarkdown: String,
    val createdAtTimestamp: Long
)

@Entity(
    tableName = "chat_messages",
    foreignKeys = [ForeignKey(
        entity = SubjectAgentEntity::class, parentColumns = ["id"],
        childColumns = ["agentId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("agentId")]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val agentId: Int,
    val sender: String,          // "USER" | "ASSISTANT"
    val text: String,
    val timestamp: Long
)
