package com.example.studyassistant.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.navArgument
import com.example.studyassistant.ui.screens.*

object Routes {
    const val MAIN = "main"
    const val SUBJECTS = "subjects"
    const val SETTINGS = "settings"
    const val WORKSPACE = "subject/{subjectId}"
    const val CHAT = "chat/{agentId}"
    const val WORK = "work/{workId}"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.MAIN, "Главная", Icons.Default.Home),
    Tab(Routes.SUBJECTS, "Предметы", Icons.AutoMirrored.Filled.List),
    Tab(Routes.SETTINGS, "Настройки", Icons.Default.Settings)
)

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    Scaffold(
        contentWindowInsets = NoInsets,
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = Routes.MAIN, modifier = Modifier.padding(pad)) {
            composable(Routes.MAIN) { MainScreen() }
            composable(Routes.SUBJECTS) { SubjectsScreen(onOpen = { nav.navigate("subject/$it") }) }
            composable(Routes.SETTINGS) { SettingsScreen() }
            composable(Routes.WORKSPACE, listOf(navArgument("subjectId") { type = NavType.IntType })) { e ->
                WorkspaceScreen(
                    subjectId = e.arguments!!.getInt("subjectId"),
                    onBack = { nav.popBackStack() },
                    onOpenAgent = { nav.navigate("chat/$it") },
                    onOpenWork = { nav.navigate("work/$it") }
                )
            }
            composable(Routes.CHAT, listOf(navArgument("agentId") { type = NavType.IntType })) { e ->
                ChatScreen(agentId = e.arguments!!.getInt("agentId"), onBack = { nav.popBackStack() })
            }
            composable(Routes.WORK, listOf(navArgument("workId") { type = NavType.IntType })) { e ->
                WorkScreen(workId = e.arguments!!.getInt("workId"), onBack = { nav.popBackStack() })
            }
        }
    }
}
