package com.example.studyassistant.data

import com.example.studyassistant.data.local.ChatMessageEntity
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlin.coroutines.cancellation.CancellationException

class GeminiRepository(private val keyStore: ApiKeyStore) {

    suspend fun validateKey(key: String): Result<Unit> = safe {
        GenerativeModel(modelName = MODEL_NAME, apiKey = key).generateContent("Ответь одним словом: ок")
        Unit
    }

    /** История уже содержит последнее сообщение пользователя. */
    suspend fun reply(systemPrompt: String, history: List<ChatMessageEntity>): Result<String> = safe {
        val key = keyStore.get()
        require(key.isNotBlank()) { "API-ключ не задан. Добавьте его в настройках." }
        val model = GenerativeModel(
            modelName = MODEL_NAME,
            apiKey = key,
            systemInstruction = content { text(systemPrompt) }
        )
        val contents = history.map { m ->
            content(role = if (m.sender == "USER") "user" else "model") { text(m.text) }
        }
        model.generateContent(*contents.toTypedArray()).text ?: error("Пустой ответ модели")
    }

    private suspend fun <T> safe(block: suspend () -> T): Result<T> =
        try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }

    companion object {
        // gemini-1.5-flash закрыт Google. Модель вынесена в константу — при необходимости замените.
        const val MODEL_NAME = "gemini-2.5-flash"
    }
}
