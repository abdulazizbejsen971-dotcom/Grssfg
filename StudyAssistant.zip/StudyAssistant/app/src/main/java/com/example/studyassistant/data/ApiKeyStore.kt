package com.example.studyassistant.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Хранит Gemini API key в зашифрованных SharedPreferences. */
class ApiKeyStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun get(): String = prefs.getString(KEY, "").orEmpty()

    fun save(key: String) {
        prefs.edit().putString(KEY, key).apply()
    }

    private companion object {
        const val KEY = "gemini_api_key"
    }
}
