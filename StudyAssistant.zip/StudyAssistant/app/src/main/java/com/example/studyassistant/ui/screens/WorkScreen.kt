package com.example.studyassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studyassistant.ui.containerViewModel
import com.example.studyassistant.ui.viewmodels.WorkViewModel
import com.mikepenz.markdown.m3.Markdown

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkScreen(workId: Int, onBack: () -> Unit) {
    val vm = containerViewModel { WorkViewModel(it.repo, workId) }
    val work by vm.work.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf(false) }
    var title by remember(work?.id) { mutableStateOf(work?.title ?: "") }
    var body by remember(work?.id) { mutableStateOf(work?.contentMarkdown ?: "") }
    val clipboard = LocalClipboardManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(work?.title ?: "") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
                actions = {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(body)) }) { Text("Копировать") }
                    TextButton(onClick = {
                        if (editing) vm.save(title.trim().ifBlank { "Без названия" }, body)
                        editing = !editing
                    }) { Text(if (editing) "Готово" else "Править") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (editing) {
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(body, { body = it }, label = { Text("Markdown") }, modifier = Modifier.fillMaxWidth(), minLines = 12)
            } else {
                Markdown(body)
            }
        }
    }
}
