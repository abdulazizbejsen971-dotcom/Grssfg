package com.example.studyassistant.data

import com.example.studyassistant.data.local.*

class StudyRepository(db: AppDatabase) {
    private val subjects = db.subjectDao()
    private val schedule = db.scheduleDao()
    private val tasks = db.taskDao()
    private val agents = db.agentDao()
    private val works = db.savedWorkDao()
    private val chat = db.chatDao()

    // Subjects
    fun observeSubjects() = subjects.observeAll()
    fun observeSubject(id: Int) = subjects.observe(id)
    suspend fun addSubject(title: String) = subjects.insert(SubjectEntity(title = title))
    suspend fun deleteSubject(id: Int) = subjects.delete(id)

    // Schedule
    fun observeSchedule(day: Int) = schedule.observeByDay(day)
    suspend fun getSchedule(day: Int) = schedule.getByDay(day)
    suspend fun addLesson(item: ScheduleEntity) = schedule.insert(item)
    suspend fun deleteLesson(id: Int) = schedule.delete(id)

    // Tasks
    fun observeTasks() = tasks.observeAll()
    suspend fun getPendingTasksBetween(from: Long, to: Long) = tasks.getPendingBetween(from, to)
    suspend fun addTask(task: TaskEntity) = tasks.insert(task)
    suspend fun setTaskDone(id: Int, done: Boolean) = tasks.setCompleted(id, done)
    suspend fun deleteTask(id: Int) = tasks.delete(id)

    // Agents
    fun observeAgents(subjectId: Int) = agents.observeBySubject(subjectId)
    fun observeAgent(id: Int) = agents.observe(id)
    suspend fun getAgent(id: Int) = agents.get(id)
    suspend fun addAgent(agent: SubjectAgentEntity) = agents.insert(agent)
    suspend fun deleteAgent(id: Int) = agents.delete(id)

    // Saved works
    fun observeWorks(subjectId: Int) = works.observeBySubject(subjectId)
    fun observeWork(id: Int) = works.observe(id)
    suspend fun saveWork(work: SavedWorkEntity) = works.insert(work)
    suspend fun updateWork(id: Int, title: String, content: String) = works.update(id, title, content)
    suspend fun deleteWork(id: Int) = works.delete(id)

    // Chat
    fun observeChat(agentId: Int) = chat.observeByAgent(agentId)
    suspend fun getChat(agentId: Int) = chat.getByAgent(agentId)
    suspend fun addMessage(message: ChatMessageEntity) = chat.insert(message)
    suspend fun clearChat(agentId: Int) = chat.clear(agentId)
}
