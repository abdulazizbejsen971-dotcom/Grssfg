package com.example.studyassistant

import android.app.Application
import android.content.Context
import com.example.studyassistant.data.ApiKeyStore
import com.example.studyassistant.data.GeminiRepository
import com.example.studyassistant.data.StudyRepository
import com.example.studyassistant.data.local.AppDatabase
import com.example.studyassistant.worker.NotificationScheduler

class AppContainer(context: Context) {
    private val db = AppDatabase.build(context)
    val repo = StudyRepository(db)
    val keyStore by lazy { ApiKeyStore(context) }
    val gemini by lazy { GeminiRepository(keyStore) }
}

class StudyApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        NotificationScheduler.schedule(this)
    }
}
