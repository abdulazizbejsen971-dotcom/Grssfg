package com.example.studyassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studyassistant.ui.NoInsets
import com.example.studyassistant.ui.containerViewModel
import com.example.studyassistant.ui.viewmodels.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    val vm = containerViewModel { SettingsViewModel(it.keyStore, it.gemini) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    var visible by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Настройки API") }) },
        contentWindowInsets = NoInsets
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Gemini API Key (создайте в Google AI Studio). Ключ хранится только на устройстве в зашифрованном виде.")
            OutlinedTextField(
                value = ui.key,
                onValueChange = vm::onKeyChange,
                label = { Text("API Key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { visible = !visible }) { Text(if (visible) "Скрыть" else "Показать") } }
            )
            Button(onClick = { vm.save() }, enabled = !ui.checking) { Text("Сохранить") }
            if (ui.checking) LinearProgressIndicator(Modifier.fillMaxWidth())
            ui.message?.let {
                Text(
                    it,
                    color = if (ui.isOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
