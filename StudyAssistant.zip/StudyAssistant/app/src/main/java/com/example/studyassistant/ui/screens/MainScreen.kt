package com.example.studyassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.studyassistant.data.local.ScheduleItem
import com.example.studyassistant.data.local.SubjectEntity
import com.example.studyassistant.data.local.TaskItem
import com.example.studyassistant.ui.*
import com.example.studyassistant.ui.viewmodels.MainViewModel
import com.example.studyassistant.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val vm = containerViewModel { MainViewModel(it.repo) }
    val day by vm.day.collectAsStateWithLifecycle()
    val lessons by vm.lessons.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val subjects by vm.subjects.collectAsStateWithLifecycle()
    var showLesson by remember { mutableStateOf(false) }
    var showTask by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Расписание и задачи") }) },
        contentWindowInsets = NoInsets
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                ScrollableTabRow(selectedTabIndex = day - 1, edgePadding = 0.dp) {
                    DAY_NAMES.forEachIndexed { i, name ->
                        Tab(selected = day == i + 1, onClick = { vm.selectDay(i + 1) }, text = { Text(name) })
                    }
                }
            }
            item(key = "h_lessons") { SectionHeader("Уроки", onAdd = { showLesson = true }) }
            if (lessons.isEmpty()) item(key = "e_lessons") { Text("В этот день уроков нет") }
            items(lessons, key = { "l${it.schedule.id}" }) { item ->
                LessonCard(item, onDelete = { vm.deleteLesson(item.schedule.id) })
            }
            item(key = "h_tasks") { SectionHeader("Задачи", onAdd = { showTask = true }) }
            if (tasks.isEmpty()) item(key = "e_tasks") { Text("Задач пока нет") }
            items(tasks, key = { "t${it.task.id}" }) { item ->
                TaskRow(
                    item,
                    onToggle = { vm.setTaskDone(item.task.id, it) },
                    onDelete = { vm.deleteTask(item.task.id) }
                )
            }
        }
    }

    if (showLesson) {
        LessonDialog(
            subjects = subjects,
            onDismiss = { showLesson = false },
            onConfirm = { sid, start, end, room ->
                vm.addLesson(sid, start, end, room)
                showLesson = false
            }
        )
    }
    if (showTask) {
        TaskDialog(
            subjects = subjects,
            onDismiss = { showTask = false },
            onConfirm = { sid, title, due ->
                vm.addTask(sid, title, due)
                showTask = false
            }
        )
    }
}

@Composable
private fun LessonCard(item: ScheduleItem, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.subjectTitle, style = MaterialTheme.typography.titleMedium)
                Text("${item.schedule.startTime} – ${item.schedule.endTime}")
                if (item.schedule.room.isNotBlank()) Text(item.schedule.room, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Удалить") }
        }
    }
}

@Composable
private fun TaskRow(item: TaskItem, onToggle: (Boolean) -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = item.task.isCompleted, onCheckedChange = onToggle)
        Column(Modifier.weight(1f)) {
            Text(
                item.task.title,
                textDecoration = if (item.task.isCompleted) TextDecoration.LineThrough else null
            )
            Text(
                "${item.subjectTitle} · до ${formatDate(item.task.dueDateTimestamp)}",
                style = MaterialTheme.typography.bodySmall
            )
        }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Удалить") }
    }
}

@Composable
private fun LessonDialog(
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (subjectId: Int, start: String, end: String, room: String) -> Unit
) {
    var subjectId by remember { mutableStateOf(subjects.firstOrNull()?.id) }
    var start by remember { mutableStateOf("08:30") }
    var end by remember { mutableStateOf("10:00") }
    var room by remember { mutableStateOf("") }
    val valid = subjectId != null && TIME_REGEX.matches(start) && TIME_REGEX.matches(end)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый урок") },
        text = {
            if (subjects.isEmpty()) {
                Text("Сначала создайте предмет на вкладке «Предметы».")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SubjectPicker(subjects, subjectId) { subjectId = it }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(start, { start = it }, Modifier.weight(1f), label = { Text("Начало") }, singleLine = true)
                        OutlinedTextField(end, { end = it }, Modifier.weight(1f), label = { Text("Конец") }, singleLine = true)
                    }
                    OutlinedTextField(room, { room = it }, label = { Text("Кабинет") }, singleLine = true)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onConfirm(subjectId!!, start, end, room.trim()) }) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TaskDialog(
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (subjectId: Int, title: String, due: Long) -> Unit
) {
    var subjectId by remember { mutableStateOf(subjects.firstOrNull()?.id) }
    var title by remember { mutableStateOf("") }
    var due by remember { mutableLongStateOf(endOfTodayMillis()) }
    var showPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая задача") },
        text = {
            if (subjects.isEmpty()) {
                Text("Сначала создайте предмет на вкладке «Предметы».")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Задание") })
                    SubjectPicker(subjects, subjectId) { subjectId = it }
                    OutlinedButton(onClick = { showPicker = true }) { Text("Срок: ${formatDate(due)}") }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = subjectId != null && title.isNotBlank(), onClick = { onConfirm(subjectId!!, title.trim(), due) }) {
                Text("Добавить")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )

    if (showPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = localToUtcDateMillis(due))
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { due = utcDateToLocalEndOfDay(it) }
                    showPicker = false
                }) { Text("OK") }
            }
        ) { DatePicker(state = state) }
    }
}
