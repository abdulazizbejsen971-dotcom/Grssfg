package com.example.studyassistant.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.studyassistant.data.ApiKeyStore
import com.example.studyassistant.data.GeminiRepository
import com.example.studyassistant.data.StudyRepository
import com.example.studyassistant.data.local.*
import com.example.studyassistant.util.defaultDay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

fun <T> Flow<T>.toState(scope: CoroutineScope, initial: T): StateFlow<T> =
    stateIn(scope, SharingStarted.WhileSubscribed(5_000), initial)

// ---------------------------------------------------------------- Main
class MainViewModel(private val repo: StudyRepository) : ViewModel() {
    private val _day = MutableStateFlow(defaultDay())
    val day: StateFlow<Int> = _day

    @OptIn(ExperimentalCoroutinesApi::class)
    val lessons = _day.flatMapLatest { repo.observeSchedule(it) }.toState(viewModelScope, emptyList())
    val tasks = repo.observeTasks().toState(viewModelScope, emptyList())
    val subjects = repo.observeSubjects().toState(viewModelScope, emptyList())

    fun selectDay(day: Int) { _day.value = day }

    fun addLesson(subjectId: Int, start: String, end: String, room: String) {
        viewModelScope.launch {
            repo.addLesson(ScheduleEntity(subjectId = subjectId, dayOfWeek = _day.value, startTime = start, endTime = end, room = room))
        }
    }

    fun deleteLesson(id: Int) { viewModelScope.launch { repo.deleteLesson(id) } }

    fun addTask(subjectId: Int, title: String, due: Long) {
        viewModelScope.launch { repo.addTask(TaskEntity(subjectId = subjectId, title = title, dueDateTimestamp = due)) }
    }

    fun setTaskDone(id: Int, done: Boolean) { viewModelScope.launch { repo.setTaskDone(id, done) } }
    fun deleteTask(id: Int) { viewModelScope.launch { repo.deleteTask(id) } }
}

// ---------------------------------------------------------------- Settings
data class SettingsUi(
    val key: String = "",
    val checking: Boolean = false,
    val message: String? = null,
    val isOk: Boolean = false
)

class SettingsViewModel(
    private val store: ApiKeyStore,
    private val gemini: GeminiRepository
) : ViewModel() {
    private val _ui = MutableStateFlow(SettingsUi(key = store.get()))
    val ui: StateFlow<SettingsUi> = _ui

    fun onKeyChange(key: String) { _ui.update { it.copy(key = key, message = null) } }

    fun save() {
        val key = _ui.value.key.trim()
        store.save(key)
        if (key.isBlank()) {
            _ui.update { it.copy(message = "Ключ удалён", isOk = false) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(checking = true, message = null) }
            gemini.validateKey(key)
                .onSuccess { _ui.update { s -> s.copy(checking = false, isOk = true, message = "Ключ сохранён и работает") } }
                .onFailure { e ->
                    _ui.update { s ->
                        s.copy(checking = false, isOk = false, message = "Ключ сохранён, но проверка не прошла: ${e.localizedMessage}")
                    }
                }
        }
    }
}

// ---------------------------------------------------------------- Subjects
class SubjectsViewModel(private val repo: StudyRepository) : ViewModel() {
    val subjects = repo.observeSubjects().toState(viewModelScope, emptyList())
    fun add(title: String) { viewModelScope.launch { repo.addSubject(title) } }
    fun delete(id: Int) { viewModelScope.launch { repo.deleteSubject(id) } }
}

// ---------------------------------------------------------------- Workspace
class WorkspaceViewModel(private val repo: StudyRepository, private val subjectId: Int) : ViewModel() {
    val subject = repo.observeSubject(subjectId).toState(viewModelScope, null)
    val agents = repo.observeAgents(subjectId).toState(viewModelScope, emptyList())
    val works = repo.observeWorks(subjectId).toState(viewModelScope, emptyList())

    fun addAgent(title: String, prompt: String) {
        viewModelScope.launch { repo.addAgent(SubjectAgentEntity(subjectId = subjectId, title = title, systemPrompt = prompt)) }
    }

    fun deleteAgent(id: Int) { viewModelScope.launch { repo.deleteAgent(id) } }
    fun deleteWork(id: Int) { viewModelScope.launch { repo.deleteWork(id) } }
}

// ---------------------------------------------------------------- Chat
data class ChatUi(val loading: Boolean = false, val error: String? = null)

class ChatViewModel(
    private val repo: StudyRepository,
    private val gemini: GeminiRepository,
    private val agentId: Int
) : ViewModel() {
    val agent = repo.observeAgent(agentId).toState(viewModelScope, null)
    val messages = repo.observeChat(agentId).toState(viewModelScope, emptyList())

    private val _ui = MutableStateFlow(ChatUi())
    val ui: StateFlow<ChatUi> = _ui

    fun send(text: String) {
        if (text.isBlank() || _ui.value.loading) return
        viewModelScope.launch {
            repo.addMessage(ChatMessageEntity(agentId = agentId, sender = "USER", text = text.trim(), timestamp = System.currentTimeMillis()))
            requestReply()
        }
    }

    fun retry() {
        if (_ui.value.loading) return
        viewModelScope.launch { requestReply() }
    }

    private suspend fun requestReply() {
        val agent = repo.getAgent(agentId) ?: return
        _ui.value = ChatUi(loading = true)
        gemini.reply(agent.systemPrompt, repo.getChat(agentId))
            .onSuccess { answer ->
                repo.addMessage(ChatMessageEntity(agentId = agentId, sender = "ASSISTANT", text = answer, timestamp = System.currentTimeMillis()))
                _ui.value = ChatUi()
            }
            .onFailure { e -> _ui.value = ChatUi(error = e.localizedMessage ?: "Неизвестная ошибка") }
    }

    fun clearChat() {
        viewModelScope.launch {
            repo.clearChat(agentId)
            _ui.value = ChatUi()
        }
    }

    fun saveWork(title: String, category: String, content: String) {
        val current = agent.value ?: return
        viewModelScope.launch {
            repo.saveWork(
                SavedWorkEntity(
                    subjectId = current.subjectId, agentId = current.id, categoryName = category,
                    title = title, contentMarkdown = content, createdAtTimestamp = System.currentTimeMillis()
                )
            )
        }
    }
}

// ---------------------------------------------------------------- Saved work
class WorkViewModel(private val repo: StudyRepository, private val workId: Int) : ViewModel() {
    val work = repo.observeWork(workId).toState(viewModelScope, null)
    fun save(title: String, content: String) { viewModelScope.launch { repo.updateWork(workId, title, content) } }
}
